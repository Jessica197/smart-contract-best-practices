****************
Language Grammar
****************

.. literalinclude:: Solidity.g4
   :language: antlr
